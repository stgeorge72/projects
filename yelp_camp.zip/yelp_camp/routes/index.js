var express = require("express");

var router = express.Router();

var passport = require("passport");

var User = require("../models/user");

router.get('/', function(request, response)
{
    
    response.render('landing');
    
});

// AUTH ROUTES

// show register form

router.get('/register', function(request, response)
{
    
    response.render('register', {page: 'register'});
    
});

// handle sign up logic

router.post('/register', function(request, response)
{
    
    User.register(new User({username: request.body.username}), request.body.password, function(error, user)
    {
        
        if(error)
        {
            
            console.log(error);
            return response.render('register', {err: error.message});
            
        }
        
        passport.authenticate('local')(request, response, function()
        {
            
            request.flash('success', 'Welcome to YelpCamp ' + user.username);
            response.redirect('/campgrounds');
            
        });
        
    });
    
});

// Show Login Form

router.get('/login', function(request, response)
{
    
    response.render('login', {page: 'login'});
    
});

// handling login logic

router.post('/login', passport.authenticate('local', 
{
    
    successRedirect: '/campgrounds',
    failureRedirect: '/login'
    
}), function(request, response) {});

// logout route

router.get('/logout', function(request, response)
{
    
    request.logout();
    request.flash('success', 'Logged out');
    response.redirect('/campgrounds');
    
});


module.exports = router;