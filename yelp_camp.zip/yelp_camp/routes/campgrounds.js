var express = require("express");

var router = express.Router();

var Campground = require("../models/campground");

var middleware = require("../middleware");

router.get('/', function(request, response)
{
    
    //Get all campgrounds for DB
    Campground.find({}, function(error, allCampgrounds)
    {
        
        if(error)
        {
            
            console.log(error);
            
        }
        
        else
        {
            
            response.render('campgrounds/index', {campgrounds : allCampgrounds, page: 'campgrounds'});
            
        }
        
    });
    
    //response.render('campgrounds', { campgrounds: campgrounds });
    
});

router.post('/', middleware.isLoggedIn, function(request, response)
{
    
    var name = request.body.name;
    var price = request.body.price;
    var image = request.body.image;
    var description = request.body.description;
    var author = { id: request.user._id, username: request.user.username };
    var newCampground = {name: name, price: price, image: image, description: description, author: author};
    
   //Create a new campground and save to DB
   Campground.create(newCampground, function(error, newlyCreated)
   {
       
       if(error)
       {
           
           console.log(error);
           
       }
       
       else
       {
           
           response.redirect('/campgrounds');
           
       }
       
   });
    
});

router.get('/new', middleware.isLoggedIn,  function(request, response)
{
    
    response.render('campgrounds/new');
    
});

// SHOW - shows more info about one campground
router.get('/:id', function(request, response)
{
    
    //find the campground with provided ID
    Campground.findById(request.params.id).populate('comments').exec(function(error, foundCampground)
    {
        
        if(error || !foundCampground)
        {
            
            request.flash('error', 'Campground not found');
            response.redirect('back');
            
        }
        
        else
        {
            
            //render show template with that campground
            response.render('campgrounds/show', {campground : foundCampground});
            
        }
        
    });
    
});

// Edit Campground Route

router.get('/:id/edit', middleware.checkCampgroundOwnership, function(request, response) 
{

    Campground.findById(request.params.id, function(error, foundCampground)
    {
        
        response.render('campgrounds/edit', {campground: foundCampground});
        
    });
   
});

// Update Campground Route

router.put('/:id', middleware.checkCampgroundOwnership, function(request, response)
{
    
    Campground.findByIdAndUpdate(request.params.id, request.body.campground, function(error, updatedCampground)
    {
        
        if(error)
        {
            
            response.redirect('/');
            
        }
        
        else
        {
            
            response.redirect('/campgrounds/' + updatedCampground.id);
            
        }
        
    });
    
});

// Destroy Campground Route

router.delete('/:id', middleware.checkCampgroundOwnership, function(request, response)
{
    
    Campground.findByIdAndRemove(request.params.id, function(error)
    {
        
        if(error)
        {
            
            response.redirect('/campgrounds');
            
        }
        
        else
        {
            
            response.redirect('/campgrounds');
            
        }
        
    });
    
});

module.exports = router;
