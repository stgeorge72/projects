var express = require("express");

var router = express.Router({mergeParams: true});

var Campground = require("../models/campground");

var Comment = require("../models/comment");

var middleware = require("../middleware");

router.get('/new', middleware.isLoggedIn, function(request, response)
{
    
    Campground.findById(request.params.id, function(error, campground)
    {
        
        if(error)
        {
            
            console.log(error);
            
        }
        
        else
        {
            
            response.render('comments/new', {campground: campground});
            
        }
        
    });
    
});

router.post('/', middleware.isLoggedIn, function(request, response)
{
    
    Campground.findById(request.params.id, function(outerError, campground)
    {
        
        if(outerError)
        {
            
            console.log(outerError);
            response.redirect('/campgrounds');
            
        }
        
        else
        {
            
            Comment.create(request.body.comment, function(error, comment)
            {
                
                if(error)
                {
                    
                    request.flash('error', 'Something went wrong');
                    console.log(error);
                    
                }
                
                else
                {
                    
                    comment.author.id = request.user._id;
                    comment.author.username = request.user.username;
                    
                    comment.save();
                    
                    campground.comments.push(comment);
                    
                    campground.save();
                    request.flash('success', 'Successfully added comment');
                    response.redirect('/campgrounds/' + campground._id);
                    
                }
                
            });
            
        }
        
    });
    
});

router.get('/:comment_id/edit', middleware.checkCommentOwnership, function(request, response)
{
    
    Campground.findById(request.params.id, function(error, foundCampground)
    {
        
        if(error || foundCampground)
        {
            
            request.flash('error', 'No campground found');
            return response.redirect('back');
            
        }
        
        Comment.findById(request.params.comment_id, function(error, foundComment)
        {
        
            if(error)
            {
                
                response.redirect('back');
                
            }
            
            else
            {
                
                response.render('comments/edit', {campground_id: request.params.id, comment: foundComment});
                
            }
        
        });
        
    });
    
});

router.put('/:comment_id', middleware.checkCommentOwnership, function(request, response)
{
    
    Comment.findByIdAndUpdate(request.params.comment_id, request.body.comment, function(error, updatedComment)
    {
        
        if(error)
        {
            
            response.redirect('back');
            
        }
        
        else
        {
            
            response.redirect('/campgrounds/' + request.params.id);
            
        }
        
    });
    
});

router.delete('/:comment_id', middleware.checkCommentOwnership, function(request, response)
{
    
    Comment.findByIdAndRemove(request.params.comment_id, function(error)
    {
        
        if(error)
        {
            
            response.redirect('back');
            
        }
        
        else
        {
            
            request.flash('success', 'Comment deleted');
            response.redirect('/campgrounds/' + request.params.id);
            
        }
        
    });
    
});


module.exports = router;