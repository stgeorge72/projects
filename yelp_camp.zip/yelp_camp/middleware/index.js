// all the middleware goes here

var middlewareObj = {};

var Campground = require("../models/campground");

var Comment = require("../models/comment");

middlewareObj.checkCampgroundOwnership = function(request, response, next)
{
    
     if(request.isAuthenticated())
    {
        
        Campground.findById(request.params.id, function(error, foundCampground)
        {
            
            if(error || !foundCampground)
            {
                
                request.flash('error', 'Campground not found');
                response.redirect('back');
                
            }
            
            else
            {
                
                if(foundCampground.author.id.equals(request.user._id))
                {
                
                   next();
                    
                }
                
                else
                {
                    
                    request.flash('error', 'You do not have permission to do that');
                    response.redirect('back');
                    
                }
                
            }
            
        });
    
    }
    
    else
    {
        
        request.flash('error', 'You need to be logged in to do that');
        response.redirect('back');
        
    }
    
};

middlewareObj.checkCommentOwnership = function(request, response, next)
{
    
     if(request.isAuthenticated())
    {
        
        Comment.findById(request.params.comment_id, function(error, foundComment)
        {
            
            if(error || !foundComment)
            {
                
                request.flash('error', 'Comment not found');
                response.redirect('back');
                
            }
            
            else
            {
                
                if(foundComment.author.id.equals(request.user._id))
                {
                
                   next();
                    
                }
                
                else
                {
                    
                    request.flash('error', 'You do not have permission to do that');
                    response.redirect('back');
                    
                }
                
            }
            
        });
    
    }
    
    else
    {
        
        request.flash('error', 'You need to be logged in to do that');
        response.redirect('back');
        
    }
    
};

middlewareObj.isLoggedIn = function(request, response, next)
{
    
    if(request.isAuthenticated())
    {
        
        return next();
        
    }
    
    request.flash('error', 'You need to be logged in to do that');
    
    response.redirect('/login');
    
};


module.exports = middlewareObj;