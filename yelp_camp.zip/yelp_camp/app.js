var express = require("express");

var app = express();

var bodyParser = require("body-parser");

var mongoose = require("mongoose");

var passport = require("passport");

var LocalStrategy = require("passport-local");

var Campground = require("./models/campground");

var seedDB = require("./seeds");

var User = require("./models/user");

var Comment = require("./models/comment");

var commentRoutes = require("./routes/comments");

var campgroundRoutes = require("./routes/campgrounds");

var authRoutes = require("./routes/index");

var methodOverride = require("method-override");

var flash = require("connect-flash");


// var User = require("./models/user")

// var express      = require('express'),
//     app          = express(),
//     bodyParser   = require('body-parser'),
//     mongoose     = require('mongoose');

//seedDB();

// PASSPORT CONFIGURATION

app.use(require("express-session")(
{
    
    secret: 'Python is my first programming language',
    resave: false,
    saveUninitialized: false
    
}));

app.locals.moment = require('moment');

app.use(passport.initialize());

app.use(passport.session());

app.use(methodOverride('_method'));

app.use(flash());



passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser(User.serializeUser());

passport.deserializeUser(User.deserializeUser());

//mongoose.connect("mongodb://localhost/yelp_camp");

mongoose.connect('mongodb://stgeorge72:iam4mek2@ds221609.mlab.com:21609/yelp_camp'); 

app.use(function(request, response, next)
{
    
    response.locals.currentUser = request.user;
    response.locals.error = request.flash('error');
    response.locals.success = request.flash('success');
    next();
    
});
   
app.use(bodyParser.urlencoded( {extended: true} ));

app.set('view engine', 'ejs');

app.use(express.static(__dirname + '/public'));

app.use(authRoutes);

app.use('/campgrounds', campgroundRoutes);

app.use('/campgrounds/:id/comments', commentRoutes);

app.listen(process.env.PORT, process.env.IP, function()
{
    
    console.log('The YelpCamp Server Has Started.');
    
});